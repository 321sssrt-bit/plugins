// OpenCode provider plugins for WorkBuddy's plans, Tencent's two builds of
// WorkBuddy (CodeBuddy's desktop agent):
//   - workbuddy:    the China build, copilot.tencent.com
//   - workbuddy-ai: the international build, www.workbuddy.ai
// A WorkBuddy account signs in in the browser (Tencent's page, polled for
// the token as WorkBuddy's desktop app does) or is taken from WorkBuddy
// desktop's own sign-in. Its chats are chat completions at <endpoint>/v2,
// streamed only, with WorkBuddy's headers: a request whose User-Agent isn't
// WorkBuddy/<version> is refused (error 10085).

import { createHash, randomBytes } from "node:crypto"
import { readFileSync } from "node:fs"
import { homedir } from "node:os"
import { join } from "node:path"

const APP_VERSION = "2.0.0" // the version WorkBuddy's sign-in page is opened with
const UA_VERSION = "5.5.6" // WorkBuddy/<this> is the User-Agent the API takes
const POLL_MS = 1000
const SIGN_IN_MS = 5 * 60 * 1000
const EARLY_MS = 60 * 1000 // a token this close to its end is refreshed before a request
const LEAD_MS = 5 * 60 * 1000 // and this close, magpie renews it ahead of time (auth.refresh)
const KEEP_RENEWED_MS = 60 * 1000 // how long a refresh's result answers for the old refresh token

// [id, name, context, efforts]
const CN_MODELS = [
  ["auto", "Auto", 168000],
  ["hy4-preview-f", "Hy4 preview", 1000000, ["high"]],
  ["hy3", "Hy3", 192000, ["low", "high"]],
  ["hy3-x", "Hy3-X", 192000, ["low", "high"]],
  ["deepseek-v4.1-flash", "Deepseek-V4.1-Flash", 1000000],
  ["glm-5.3", "GLM-5.3", 1000000, ["low", "high", "max"]],
  ["glm-5.3-flash", "GLM-5.3-Flash", 1000000, ["low", "high", "max"]],
  ["glm-5.2", "GLM-5.2", 1000000, ["high", "xhigh"]],
  ["glm-5.1", "GLM-5.1", 200000],
  ["glm-5v-turbo", "GLM-5v-Turbo", 200000],
  ["minimax-m3", "MiniMax-M3", 512000],
  ["kimi-k3-1", "Kimi-K3", 1000000, ["low", "high", "xhigh"]],
  ["kimi-k2.7", "Kimi-K2.7-Code", 256000],
  ["kimi-k2.6", "Kimi-K2.6", 256000],
  ["deepseek-v4-pro", "Deepseek-V4-Pro", 1000000, ["none", "high", "xhigh"]],
]

const AI_MODELS = [
  ["default-model", "Default", 176000],
  ["fast-model", "Fast", 200000],
  ["balanced-model", "Balanced", 256000],
  ["primary-model", "Primary", 272000],
  ["deep-model", "Deep", 176000],
  ["gpt-5.5", "GPT-5.5", 1000000],
  ["gpt-5.4", "GPT-5.4", 272000],
  ["gpt-5.3-codex", "GPT-5.3-Codex", 272000],
  ["gemini-3.1-pro", "Gemini-3.1-Pro", 400000],
  ["gemini-3.5-flash", "Gemini-3.5-Flash", 1000000],
  ["glm-5.3", "GLM-5.3", 1000000, ["low", "high", "max"]],
  ["glm-5.2", "GLM-5.2", 1000000, ["high", "xhigh"]],
  ["hy3", "Hy3", 192000, ["low", "high"]],
  ["kimi-k3", "Kimi-K3", 1000000],
  ["kimi-k2.6", "Kimi-K2.6", 256000],
  ["minimax-m3", "MiniMax-M3", 512000],
]

const SITES = {
  workbuddy: {
    id: "workbuddy",
    name: "WorkBuddy",
    endpoint: "https://copilot.tencent.com",
    authID: "workbuddy-desktop",
    platform: "workbuddy",
    ai: false,
    models: CN_MODELS,
  },
  "workbuddy-ai": {
    id: "workbuddy-ai",
    name: "WorkBuddy AI",
    endpoint: "https://www.workbuddy.ai",
    authID: "workbuddy-desktop-ai",
    platform: "workbuddy-ai",
    ai: true,
    models: AI_MODELS,
    // models whose images WorkBuddy AI drops though its config says they
    // take them (see textOnly)
    noImages: /^glm-/,
  },
}

// textOnly says whether site drops the images sent to model, whatever its
// config says. On 2026-10-13, with a real WorkBuddy AI account (Yirasumi on
// Discord), www.workbuddy.ai's /v3/config marked every model
// supportsImages: true, but a chat to glm-5.3-flash, glm-5.3 or glm-5.2
// came back saying "[System reminder: the current model does not support
// images. Content filtered. ...]": the server had taken the image out.
// Its other models (deepseek-v4.1-flash, kimi, gemini, grok, gpt) read
// them, and WorkBuddy (China)'s glm-5.3-flash does too, so this is WorkBuddy
// AI's GLM models alone. Said text-only, magpie's image-describing model
// reads the image for them; a user who said the model takes images keeps
// their own answer (magpie's settings, over what this list says).
function textOnly(site, model) {
  return !!site.noImages?.test(model)
}

const NPM = "@ai-sdk/openai-compatible"
const hex = () => randomBytes(16).toString("hex")
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const api = (site) => site.endpoint + "/v2"

// ---- WorkBuddy's API ------------------------------------------------------

class WBError extends Error {
  constructor(message, code, status, said) {
    super(message)
    this.code = code
    this.status = status
    this.said = said // as magpie's built-in (wbCall) worded it
  }
}

// call makes a request of WorkBuddy's plugin API, which answers
// {code, msg, data}; a code but 0 is an error.
async function call(site, method, path, headers = {}, body) {
  const res = await fetch(site.endpoint + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": "WorkBuddy/" + UA_VERSION,
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(30000),
  })
  const text = await res.text()
  let env = {}
  try {
    env = JSON.parse(text)
  } catch {}
  const code = Number.parseInt(env.code, 10) || 0
  if (!res.ok) {
    const why = env.msg || env.message || env.error?.message || text.slice(0, 200) || res.statusText
    const said = code ? env.msg || `error ${code}` : env.msg || statusText(res.status)
    throw new WBError(`${site.name}: ${why} (HTTP ${res.status}${env.code ? ", code " + env.code : ""})`, env.code, res.status, said)
  }
  if (env.code) throw new WBError(`${site.name}: ${env.msg || "error"} (${env.code})`, env.code, res.status, env.msg || `error ${code}`)
  return env.data
}

function domainOf(site, a) {
  return a.domain || new URL(api(site)).host
}

// merge takes a token WorkBuddy gave (sign-in or refresh) into the
// stored sign-in, times given as at-ms or in-seconds.
function merge(a, got) {
  const now = Date.now()
  const out = { ...a, access: got.accessToken }
  if (got.refreshToken) out.refresh = got.refreshToken
  if (got.domain) out.domain = got.domain
  if (got.tokenType) out.tokenType = got.tokenType
  if (got.expiresAt > 0) out.expires = got.expiresAt
  else if (got.expiresIn > 0) out.expires = now + got.expiresIn * 1000
  if (got.refreshExpiresAt > 0) out.refreshExpiresAt = got.refreshExpiresAt
  else if (got.refreshExpiresIn > 0) out.refreshExpiresAt = now + got.refreshExpiresIn * 1000
  return out
}

function stale(a) {
  return !!a.expires && Date.now() >= a.expires - EARLY_MS
}

// renewing is each refresh under way, by site and the refresh token it
// spends; renewed is what each gave, kept a minute so one that read the
// old refresh token after it was spent (magpie's auth.refresh, a request)
// takes that rather than spending it again.
const renewing = new Map()
const renewed = new Map()

function refreshable(a) {
  return !!a.refresh && !(a.refreshExpiresAt && Date.now() >= a.refreshExpiresAt)
}

// renew spends a's refresh token, once: those who come while it runs, or
// within KEEP_RENEWED_MS of it, get what it gave. save keeps the result.
function renew(site, a, save) {
  const key = site.id + "\n" + a.refresh
  const done = renewed.get(key)
  if (done && Date.now() - done.at < KEEP_RENEWED_MS) return Promise.resolve(merged(a, done.next))
  let r = renewing.get(key)
  if (!r) {
    r = (async () => {
      const got = await call(site, "POST", "/v2/plugin/auth/token/refresh", {
        "X-Refresh-Token": a.refresh,
        "X-Auth-Refresh-Source": "plugin",
        "X-Domain": domainOf(site, a),
        ...enterpriseHeaders(a),
      }, {})
      if (!got?.accessToken) throw Object.assign(new Error("WorkBuddy gave no refreshed token"), { bare: true })
      const next = merge(a, got)
      renewed.set(key, { next, at: Date.now() })
      await save?.(next)
      return next
    })().finally(() => renewing.delete(key))
    renewing.set(key, r)
  }
  return r.then((next) => merged(a, next))
}

// merged is a with the tokens another's refresh gave over it.
function merged(a, next) {
  const out = { ...a }
  for (const k of TOKEN_FIELDS) if (k in next) out[k] = next[k]
  return out
}
const TOKEN_FIELDS = ["access", "refresh", "expires", "refreshExpiresAt", "domain", "tokenType"]

// fresh is the sign-in with an access token that isn't about to end:
// refreshed (and saved) when it is. A refresh that fails, or a refresh
// token that has ended, leaves the access token there is. Its failures
// are worded as the built-in's (wbFresh), "WorkBuddy" on both sites.
async function fresh(site, client, a) {
  if (!stale(a)) return a
  if (!refreshable(a)) {
    if (a.access) return a
    throw new Error("this WorkBuddy account is signed out; sign in again")
  }
  try {
    return await renew(site, a, async (next) => {
      try {
        await client?.auth?.set?.({ path: { id: site.id }, body: next })
      } catch {}
    })
  } catch (e) {
    if (a.access) return a
    if (e?.bare) throw e
    throw new Error(`WorkBuddy token refresh: ${e?.said ?? e?.message ?? e}`)
  }
}

// refreshed is what magpie's auth.refresh gives for a browser sign-in:
// the fields a refresh changed, nothing when there's nothing to renew.
// magpie saves them itself.
async function refreshed(site, auth) {
  if (auth?.type !== "oauth" || auth.source === "desktop" || !auth.access || !auth.refresh) return undefined
  // a refresh token that has ended is said plainly, never as signIn
  // "expired": the built-in never marked a WorkBuddy account
  if (!refreshable(auth)) throw new Error("this WorkBuddy account is signed out; sign in again")
  let next
  try {
    next = await renew(site, auth)
  } catch (e) {
    if (e?.bare) throw e
    throw new Error(`WorkBuddy token refresh: ${e?.said ?? e?.message ?? e}`)
  }
  const out = {}
  for (const k of TOKEN_FIELDS) if (k in next && next[k] !== auth[k]) out[k] = next[k]
  return Object.keys(out).length ? out : undefined
}

// sign sets on headers what WorkBuddy's desktop app sends with a chat: the
// account's own, the client's, and the attribution WorkBuddy's usage list
// shows as the client that asked (使用端). The chat's ids — the
// conversation's, the turn's, the message's — are attend's below.
//
// WorkBuddy's own client sends the whole of this on both builds
// (application-manifest.js: X-Agent-Purpose "conversation", X-IDE-Name/Type
// "WorkBuddy", X-IDE-Version, X-Product "SaaS"); a chat without them is
// counted under no client at all, which is the empty 使用端 a request shows
// when only some of the group is there. The gate below used to give the China
// build none of the client's headers, so every China-build request was
// attribution-less.
function sign(site, a, headers) {
  headers.set("Authorization", "Bearer " + a.access)
  headers.set("X-User-Id", a.uid ?? "")
  headers.set("X-Domain", domainOf(site, a))
  headers.set("X-Product", "SaaS")
  headers.set("X-IDE-Type", "WorkBuddy")
  headers.set("User-Agent", "WorkBuddy/" + UA_VERSION)
  headers.set("X-Requested-With", "XMLHttpRequest")
  headers.set("X-Agent-Intent", "craft")
  headers.set("X-Agent-Purpose", "conversation")
  headers.set("X-IDE-Name", "WorkBuddy")
  headers.set("X-IDE-Version", UA_VERSION)
  for (const [k, v] of Object.entries(enterpriseHeaders(a))) headers.set(k, v)
  if (!site.ai) return
  headers.set("X-Agent-Type", "main")
}

// enterpriseHeaders names the enterprise (team) an account signed in as, as
// WorkBuddy's own client does on every request it makes for that account
// (its auth interceptor: X-Enterprise-Id and X-Tenant-Id, both the
// account's enterpriseId). Without them WorkBuddy answers as the personal
// account: /v3/config lists the personal plan's models and not the
// enterprise's (#75). A personal account has none and sends none.
function enterpriseHeaders(a) {
  const id = typeof a?.enterpriseId === "string" ? a.enterpriseId.trim() : ""
  return id ? { "X-Enterprise-Id": id, "X-Tenant-Id": id } : {}
}

// enterpriseOf is the enterprise the account a sign-in gave belongs to:
// the one /login/account names, else, for an account that isn't personal,
// the one WorkBuddy's account list has for it — the same choice WorkBuddy's
// own client makes (mergeCurrentAccountDetails): the uid's only entry of that
// type, or the only one it last signed in to. None found is personal.
async function enterpriseOf(site, a, who) {
  const own = typeof who?.enterpriseId === "string" ? who.enterpriseId.trim() : ""
  if (own) return own
  const type = String(who?.type ?? "").trim().toLowerCase()
  if (!type || type === "personal") return ""
  let list
  try {
    list = await call(site, "GET", "/v2/plugin/accounts", {
      Authorization: "Bearer " + a.access,
      "X-Domain": domainOf(site, a),
    })
  } catch {
    return ""
  }
  const mine = (list?.accounts ?? []).filter((x) => x?.uid === who.uid && typeof x.enterpriseId === "string" && x.enterpriseId.trim())
  const same = mine.filter((x) => String(x.type ?? "").trim().toLowerCase() === type)
  const last = mine.filter((x) => x.lastLogin)
  const pick = same.length === 1 ? same[0] : last.length === 1 ? last[0] : mine.length === 1 ? mine[0] : undefined
  return pick ? pick.enterpriseId.trim() : ""
}

// WorkBuddy's own client names each chat to its gateway four ways: the
// conversation it belongs to, the user send (turn) it answers, the message
// itself, and the request that carried it. Its backend counts a user send as
// one request by X-Conversation-Request-ID: a chat carrying a new one every
// time is counted on its own, so one send that takes several steps — a tool
// call answered and sent again, a retry, another account answering — shows up
// in the usage detail as many requests. The ids below are made from what
// names the conversation and the turn, so every step of one send carries the
// same turn id and the user's next message carries another, as WorkBuddy's
// own client does.

// SESSION carries the conversation magpie (or OpenCode) names a request by,
// from the chat.headers hook to the loader's fetch. It goes no further.
const SESSION = "x-magpie-workbuddy-session"

// SALT is what the ids are derived with, so an id says nothing of the words
// it was made from. New in each process, as WorkBuddy's own ids are one
// conversation's own within a run.
const SALT = randomBytes(16).toString("hex")

// idFor is the 32 hex digits WorkBuddy's own ids are made of, made of a
// name of the thing the id is for (a turn, a conversation) and what names it.
function idFor(kind, key) {
  return createHash("sha256").update(`${SALT}|${kind}|${key}`).digest("hex").slice(0, 32)
}

// signatureOf is a message content's signature: its text, and a digest of
// every part that isn't text (an image, a file), so a turn of images alone is
// a turn of its own too. A tool result's part — carried in a user message by
// clients of Anthropic's shape — is left out: it is not what the user said,
// and it changes with every step of the send.
function signatureOf(content) {
  if (typeof content === "string") return content
  if (!Array.isArray(content)) return ""
  let out = ""
  for (const part of content) {
    const type = part?.type ?? ""
    if (type === "" || type === "text") out += typeof part?.text === "string" ? part.text : ""
    else if (type !== "tool_result" && type !== "tool-result") {
      out += `[${type}:${createHash("sha256").update(JSON.stringify(part)).digest("hex").slice(0, 8)}]`
    }
  }
  return out
}

// answeredBefore is whether msgs[i] answers the message before it — a tool's
// result, or an assistant's calls — rather than carrying the user's own
// words. A client that sends a tool result's images in a user message (pi's
// "Attached image(s) from tool result:") puts that message right after the
// result, and a turn keyed on it would be a turn of its own on every step.
function answeredBefore(msgs, i) {
  const prev = msgs[i - 1]
  if (prev === null || typeof prev !== "object") return false
  if (prev.role === "tool") return true
  return prev.role === "assistant" && Array.isArray(prev.tool_calls) && prev.tool_calls.length > 0
}

// turnKey names the user send a chat answers: the body's last user message
// that is the user's own, by its place and its signature. Every step of one
// send repeats it; the user's next message changes it. "" for a chat whose
// last such message has nothing signable in it (an empty message) or which
// has none at all: the caller then makes a fresh id for that request, as
// before these were derived at all.
function turnKey(chat) {
  const msgs = Array.isArray(chat?.messages) ? chat.messages : []
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i]?.role !== "user" || answeredBefore(msgs, i)) continue
    const sig = signatureOf(msgs[i].content)
    return sig ? `u${i}:${sig}` : ""
  }
  return ""
}

// conversationKey names the conversation a chat belongs to: the session
// magpie or OpenCode names (its chat.headers hook), else the chat's first
// user message, which every later turn of it repeats. "" when neither names
// one — a body that isn't a chat, or one with no user message in it — and no
// conversation id is sent then: a made-up one would be a conversation of the
// request's own, which is what fragments the usage detail in the first place.
function conversationKey(chat, session) {
  if (session) return `session:${session}`
  const msgs = Array.isArray(chat?.messages) ? chat.messages : []
  for (const m of msgs) {
    if (m?.role !== "user") continue
    const sig = signatureOf(m.content)
    if (sig) return `first:${sig}`
  }
  return ""
}

// chatOf is a chat's body as the object it is, null for one that isn't: a
// body that isn't text (bytes), or isn't JSON at all.
function chatOf(body) {
  if (typeof body !== "string") return null
  try {
    const b = JSON.parse(body)
    return b !== null && typeof b === "object" ? b : null
  } catch {
    return null
  }
}

// sessionOf takes the session a chat.headers hook named off the headers,
// with the header: it goes no further than here. Its length is capped as
// magpie's own session ids are, the id below being derived from it anyway.
function sessionOf(headers) {
  const s = String(headers.get(SESSION) ?? "").trim()
  headers.delete(SESSION)
  return s.slice(0, 128)
}

// attend sets a chat's ids on the headers its request goes to WorkBuddy
// with: the message's (each request its own, as the client makes them), the
// turn's (one user send, whatever it takes), and the conversation's. A header
// already there — the caller's own, or another plugin's — is kept, and the
// message and request ids are the same one, as WorkBuddy's client has them.
function attend(headers, body, session) {
  const chat = chatOf(body)
  const conv = conversationKey(chat, session)
  const msg = hex()
  headers.set("X-Conversation-Message-ID", msg)
  headers.set("X-Request-ID", msg)
  if (!headers.has("X-Conversation-Request-ID")) {
    const turn = turnKey(chat)
    // a turn is a conversation's own: two conversations whose user message
    // reads the same are still two sends, not one
    headers.set("X-Conversation-Request-ID", turn ? idFor("turn", `${conv}|${turn}`) : hex())
  }
  if (conv && !headers.has("X-Conversation-ID")) headers.set("X-Conversation-ID", idFor("conversation", conv))
}

// FLAGGED are the words WorkBuddy refuses a chat for, "Illegal API
// invocation from an unapproved channel" (magpie #182), each with words
// that say the same and pass: tried one by one against both builds with
// the requests Claude Code 2.1.280 and Codex 0.159.2 send. WorkBuddy reads
// every message, not only the system prompt (Claude Code puts its main
// branch in the first user message), and pays no mind to case. Claude
// Code's billing header means nothing to WorkBuddy's models and goes.
const FLAGGED = [
  [/x-anthropic-billing-header:[^\n]*\n?/gi, ""],
  [/You are Claude Code, Anthropic['’]s official CLI for Claude/gi, "You are Claude Code, Anthropic's CLI for Claude"],
  [/Main branch \(you will usually use this for PRs\)/gi, "Main branch (usually the base for PRs)"],
  [/(?<!the )Codex CLI is an open source project led by OpenAI\./gi, "The Codex CLI is an open source project led by OpenAI."],
]

function unflagged(text) {
  for (const [re, to] of FLAGGED) text = text.replace(re, to)
  return text
}

// unflag puts FLAGGED's words in place in every message of a chat, and
// leaves out a text that had nothing else (the billing header's system
// block). It says whether it changed anything.
function unflag(messages) {
  let changed = false
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]
    if (typeof m?.content === "string") {
      const t = unflagged(m.content)
      if (t === m.content) continue
      changed = true
      if (t.trim() || m.role !== "system") m.content = t
      else messages.splice(i, 1)
    } else if (Array.isArray(m?.content)) {
      const parts = []
      let here = false
      for (const p of m.content) {
        const t = typeof p?.text === "string" ? unflagged(p.text) : null
        if (t === null || t === p.text) {
          parts.push(p)
          continue
        }
        here = true
        if (t.trim()) parts.push({ ...p, text: t })
      }
      if (!here) continue
      changed = true
      if (parts.length || m.role !== "system") m.content = parts
      else messages.splice(i, 1)
    }
  }
  return changed
}

// withSystem gives a chat that doesn't open with a system message
// WorkBuddy's default one, as its app does, takes FLAGGED's words out of it,
// and applies the request spellings WorkBuddy's chat endpoint accepts. The
// OpenAI-compatible client normally uses max_completion_tokens and may call a
// reasoning prompt developer; WorkBuddy's endpoint takes max_tokens and
// system instead.
function withSystem(body) {
  // a body magpie or OpenCode hands over as bytes is read as the text it is
  if (body instanceof ArrayBuffer || ArrayBuffer.isView(body)) body = new TextDecoder().decode(body)
  if (typeof body !== "string") return body
  try {
    const b = JSON.parse(body)
    if (!Array.isArray(b?.messages) || !b.messages.length) return body
    let changed = unflag(b.messages)
    if (b.max_completion_tokens !== undefined) {
      if (b.max_tokens === undefined) b.max_tokens = b.max_completion_tokens
      delete b.max_completion_tokens
      changed = true
    }
    for (const m of b.messages) {
      if (m?.role !== "developer") continue
      m.role = "system"
      changed = true
    }
    if (b.messages[0]?.role !== "system") {
      b.messages.unshift({ role: "system", content: "You are a helpful assistant." })
      changed = true
    }
    return changed ? JSON.stringify(b) : body
  } catch {
    return body
  }
}

// normalizeToolChoice converts the object form emitted by OpenAI clients to
// WorkBuddy's string form. It runs after fitted(), so a named choice follows a
// tool name that was made safe for WorkBuddy.
function normalizeToolChoice(body) {
  if (typeof body !== "string") return body
  try {
    const b = JSON.parse(body)
    if (!b || typeof b !== "object" || Array.isArray(b) || !("tool_choice" in b)) return body
    const choice = b.tool_choice
    if (typeof choice === "string") {
      if (choice.trim().toLowerCase() === "none") {
        delete b.tool_choice
        delete b.tools
        delete b.functions
      }
      return JSON.stringify(b)
    }
    if (!choice || typeof choice !== "object" || Array.isArray(choice)) {
      delete b.tool_choice
      return JSON.stringify(b)
    }
    const type = typeof choice.type === "string" ? choice.type.trim().toLowerCase() : ""
    if (type === "none") {
      delete b.tool_choice
      delete b.tools
      delete b.functions
    } else if (type === "auto" || type === "required") {
      b.tool_choice = type
    } else if (type === "function") {
      const fn = choice.function && typeof choice.function === "object" && !Array.isArray(choice.function)
        ? choice.function
        : undefined
      const name = typeof fn?.name === "string" ? fn.name.trim() : ""
      b.tool_choice = name || "auto"
    } else {
      delete b.tool_choice
    }
    return JSON.stringify(b)
  } catch {
    return body
  }
}

// ---- tools WorkBuddy takes ----------------------------------------------------

// WorkBuddy AI answers 400 code 11133 "Invalid request parameters" (the
// model provider rejected them) to a chat whose tools it can't pass on to
// the model (wyh on magpie's Discord: ZCode and DeepSeek Harness on
// deepseek-v4.1-flash). Tried on the owner's account, 2026-10-08: DeepSeek
// turns away each of the shapes below, and Kimi, GPT, Gemini and GLM some
// of them; MiniMax none. fitTools gives each a shape every model takes.
// A tool's name may hold letters, digits, _ and -; another character
// (". : / space", CJK) is refused.
const NAME_OK = /^[A-Za-z0-9_-]+$/

// safeName is name with each character WorkBuddy refuses as _, kept apart
// from the names in taken.
function safeName(name, taken) {
  const base = String(name).replace(/[^A-Za-z0-9_-]/g, "_") || "tool"
  let n = base
  for (let i = 2; taken.has(n); i++) n = `${base}_${i}`
  taken.add(n)
  return n
}

// NUL_ESCAPE finds a regex's \0 (the NUL character), stepping over each \\
// (a backslash) so that a \\0 is left; \01 is an octal escape, also left.
const NUL_ESCAPE = /\\\\|\\0(?![0-9])/g

// fitSchema mends a schema in place, at every depth: a pattern's \0, which
// DeepSeek's validator says is "not a 'regex'", is \u0000, which matches
// the same (magpie's gateway does this for DeepSeek's own API,
// deepseekToolPatterns); a tuple's items (a list) become one schema any of
// them fits. It reports whether it changed anything.
function fitSchema(s, depth = 0) {
  if (!s || typeof s !== "object" || depth > 64) return false
  let changed = false
  if (Array.isArray(s)) {
    for (const v of s) if (fitSchema(v, depth + 1)) changed = true
    return changed
  }
  if (typeof s.pattern === "string" && s.pattern.includes("\\0")) {
    const p = s.pattern.replace(NUL_ESCAPE, (m) => (m === "\\\\" ? m : "\\u0000"))
    if (p !== s.pattern) {
      s.pattern = p
      changed = true
    }
  }
  if (Array.isArray(s.items)) {
    const list = s.items.filter((v) => v && typeof v === "object")
    s.items = list.length === 0 ? {} : list.length === 1 ? list[0] : { anyOf: list }
    delete s.additionalItems
    changed = true
  }
  for (const v of Object.values(s)) if (fitSchema(v, depth + 1)) changed = true
  return changed
}

// Kimi (kimi-k3-1) answers 11133 too, to the tools of an MCP server or a
// plugin (clearmann, #122). Tried on the owner's account, 2026-10-14, each
// alone in an otherwise plain chat: Kimi turns away an enum with no type
// (["a","b"] as much as [1,"a",null]), an empty enum, an enum whose type
// lists two types besides null, a schema that is true or false where a
// schema goes (properties.x: true, items: true), a required that isn't a
// list, and a type it doesn't know ("any", "String"). It takes an enum
// typed T or [T, "null"], an anyOf of such enums, {"not": {}}, {}, and
// additionalProperties: true or false. fitShape gives each the shape it
// takes, meaning the same: none of it narrows or widens what a call may
// hold, except an empty enum (which nothing fits) is left out.
const TYPES = new Set(["string", "number", "integer", "boolean", "object", "array", "null"])

// SUB_ONE are the keywords whose value is a schema, SUB_LIST a list of
// schemas, SUB_MAP a map of names to schemas. additionalProperties and
// unevaluatedProperties are left as they are when true or false.
const SUB_ONE = ["items", "additionalItems", "unevaluatedItems", "contains", "not", "if", "then", "else", "propertyNames", "additionalProperties", "unevaluatedProperties"]
const SUB_LIST = ["anyOf", "oneOf", "allOf", "prefixItems"]
const SUB_MAP = ["properties", "patternProperties", "$defs", "definitions", "dependentSchemas"]
const BOOL_OK = new Set(["additionalProperties", "unevaluatedProperties"])

// valueType is the JSON Schema type of an enum's value.
function valueType(v) {
  if (v === null) return "null"
  if (Array.isArray(v)) return "array"
  if (typeof v === "number") return Number.isInteger(v) ? "integer" : "number"
  return typeof v
}

// fitEnum gives s's enum a type: the one its values have, or that and
// "null"; values of several types are an anyOf of an enum for each. It
// reports whether it changed anything.
function fitEnum(s) {
  if (!("enum" in s)) return false
  if (!Array.isArray(s.enum) || s.enum.length === 0) {
    delete s.enum
    return true
  }
  const listed = Array.isArray(s.type) ? s.type : typeof s.type === "string" ? [s.type] : []
  if (listed.filter((t) => t !== "null").length === 1) return false
  const byType = new Map()
  for (const v of s.enum) {
    const t = valueType(v)
    if (!byType.has(t)) byType.set(t, [])
    byType.get(t).push(v)
  }
  if (byType.has("integer") && byType.has("number")) {
    byType.get("number").push(...byType.get("integer"))
    byType.delete("integer")
  }
  const hasNull = byType.delete("null")
  if (byType.size <= 1) {
    const [t] = byType.keys()
    const want = t === undefined ? "null" : hasNull ? [t, "null"] : t
    if (JSON.stringify(want) === JSON.stringify(s.type)) return false
    s.type = want
    return true
  }
  const split = [...byType].map(([t, vs]) => ({ type: t, enum: vs }))
  if (hasNull) split.push({ type: "null" })
  delete s.enum
  delete s.type
  if (Array.isArray(s.anyOf)) s.allOf = [...(Array.isArray(s.allOf) ? s.allOf : []), { anyOf: split }]
  else s.anyOf = split
  return true
}

// subSchema is v, a schema found under key, as an object Kimi takes: true
// is {}, false is {"not": {}}.
function subSchema(v, key) {
  if (typeof v !== "boolean" || BOOL_OK.has(key)) return v
  return v ? {} : { not: {} }
}

// fitShape mends s, a schema, and each schema under it, in place (see
// TYPES above); a name under properties is never read as a keyword. It
// reports whether it changed anything.
function fitShape(s, depth = 0) {
  if (!s || typeof s !== "object" || Array.isArray(s) || depth > 64) return false
  let changed = false
  if ("type" in s) {
    const list = (Array.isArray(s.type) ? s.type : [s.type]).map((t) => (typeof t === "string" ? t.toLowerCase() : t)).filter((t) => TYPES.has(t))
    const uniq = [...new Set(list)]
    const want = uniq.length === 0 ? undefined : uniq.length === 1 ? uniq[0] : uniq
    if (JSON.stringify(want) !== JSON.stringify(s.type)) {
      if (want === undefined) delete s.type
      else s.type = want
      changed = true
    }
  }
  if ("required" in s && !Array.isArray(s.required)) {
    delete s.required
    changed = true
  } else if (Array.isArray(s.required) && s.required.some((k) => typeof k !== "string")) {
    s.required = s.required.filter((k) => typeof k === "string")
    changed = true
  }
  if (fitEnum(s)) changed = true
  for (const k of SUB_ONE) {
    if (!(k in s)) continue
    const v = subSchema(s[k], k)
    if (v !== s[k]) {
      s[k] = v
      changed = true
    }
    if (fitShape(v, depth + 1)) changed = true
  }
  for (const k of SUB_LIST) {
    if (!Array.isArray(s[k])) continue
    s[k].forEach((v0, i) => {
      const v = subSchema(v0, k)
      if (v !== v0) {
        s[k][i] = v
        changed = true
      }
      if (fitShape(v, depth + 1)) changed = true
    })
  }
  for (const k of SUB_MAP) {
    const m = s[k]
    if (!m || typeof m !== "object" || Array.isArray(m)) continue
    for (const [name, v0] of Object.entries(m)) {
      const v = subSchema(v0, k)
      if (v !== v0) {
        m[name] = v
        changed = true
      }
      if (fitShape(v, depth + 1)) changed = true
    }
  }
  return changed
}

// localRef is the schema a local $ref in root names ("#/$defs/x",
// "#/definitions/x"), or s itself.
function localRef(root, s) {
  const ref = s?.$ref
  if (typeof ref !== "string" || !ref.startsWith("#/")) return s
  let at = root
  for (const k of ref.slice(2).split("/")) at = at?.[k.replaceAll("~1", "/").replaceAll("~0", "~")]
  return at && typeof at === "object" ? at : s
}

// objectRoot makes a tool's parameters an object at the root, as magpie's
// gateway does for xAI (provider.ObjectRoot): allOf's branches are merged
// whole; of anyOf's and oneOf's object branches the properties are merged
// and a field each requires stays required. A root with no type, or an
// empty one, is an object. It reports whether it changed anything.
function objectRoot(ps, root = ps, depth = 0) {
  const unions = ["allOf", "anyOf", "oneOf"].filter((k) => Array.isArray(ps[k]))
  if (ps.type === "object" && !unions.length) return false
  const props = ps.properties && typeof ps.properties === "object" ? ps.properties : {}
  const required = Array.isArray(ps.required) ? [...ps.required] : []
  for (const b0 of ps.allOf ?? []) {
    let b = localRef(root, b0)
    if (!b || typeof b !== "object") continue
    if (depth < 8 && ["allOf", "anyOf", "oneOf"].some((k) => Array.isArray(b[k]))) objectRoot((b = structuredClone(b)), root, depth + 1)
    for (const [k, v] of Object.entries(b.properties ?? {})) if (!(k in props)) props[k] = v
    if (Array.isArray(b.required)) required.push(...b.required)
  }
  const branches = []
  for (const key of ["anyOf", "oneOf"]) {
    for (const b0 of ps[key] ?? []) {
      let b = localRef(root, b0)
      if (!b || typeof b !== "object") continue
      if (depth < 8 && ["allOf", "anyOf", "oneOf"].some((k) => Array.isArray(b[k]))) objectRoot((b = structuredClone(b)), root, depth + 1)
      if (b.type !== "object" && !b.properties) continue
      branches.push(b)
    }
  }
  const from = new Map()
  for (const b of branches) {
    for (const [k, v] of Object.entries(b.properties ?? {})) {
      if (k in props) continue
      const seen = from.get(k) ?? []
      if (!seen.some((x) => JSON.stringify(x) === JSON.stringify(v))) seen.push(v)
      from.set(k, seen)
    }
  }
  for (const [k, list] of from) props[k] = list.length === 1 ? list[0] : { anyOf: list }
  if (branches.length) {
    for (const k of Object.keys(branches[0].properties ?? {})) {
      if (branches.every((b) => Array.isArray(b.required) && b.required.includes(k))) required.push(k)
    }
  }
  for (const k of unions) delete ps[k]
  ps.type = "object"
  ps.properties = props
  const req = [...new Set(required)].filter((k) => typeof k === "string" && k in props)
  if (req.length) ps.required = req
  else delete ps.required
  return true
}

// fitTools mends b's function tools in place: their parameters (fitSchema,
// fitShape, objectRoot) and names. It reports whether it changed anything,
// and the names it gave, each to the name the client knows (ours), so that the
// model's calls are named back. A call in the chat's history is named as
// its tool now is.
function fitTools(b) {
  const names = new Map()
  if (!Array.isArray(b?.tools) || !b.tools.length) return { changed: false, names }
  let changed = false
  const taken = new Set()
  for (const t of b.tools) {
    const n = t?.function?.name
    if (typeof n === "string" && NAME_OK.test(n)) taken.add(n)
  }
  const theirs = new Map()
  for (const t of b.tools) {
    const fn = t?.type === "function" || t?.function ? t.function : null
    if (!fn || typeof fn !== "object") continue
    if (typeof fn.name === "string" && !NAME_OK.test(fn.name)) {
      const safe = safeName(fn.name, taken)
      names.set(safe, fn.name)
      theirs.set(fn.name, safe)
      fn.name = safe
      changed = true
    }
    if (fn.parameters === undefined) continue
    if (!fn.parameters || typeof fn.parameters !== "object" || Array.isArray(fn.parameters)) {
      fn.parameters = { type: "object", properties: {} }
      changed = true
      continue
    }
    if (fitSchema(fn.parameters)) changed = true
    if (fitShape(fn.parameters)) changed = true
    if (objectRoot(fn.parameters)) changed = true
  }
  if (theirs.size && Array.isArray(b.messages)) {
    for (const m of b.messages) {
      for (const c of Array.isArray(m?.tool_calls) ? m.tool_calls : []) {
        const safe = theirs.get(c?.function?.name)
        if (safe) c.function.name = safe
      }
      if (m?.role === "tool" && theirs.has(m.name)) m.name = theirs.get(m.name)
    }
  }
  const choice = b.tool_choice?.function
  if (choice && theirs.has(choice.name)) choice.name = theirs.get(choice.name)
  return { changed, names }
}

// fitted is a chat body with its tools mended (fitTools), and the names
// given its tools, each to the client's own; a body that isn't a chat is
// as it was.
function fitted(body) {
  if (typeof body !== "string") return { body, names: new Map() }
  try {
    const b = JSON.parse(body)
    const { changed, names } = fitTools(b)
    return { body: changed ? JSON.stringify(b) : body, names }
  } catch {
    return { body, names: new Map() }
  }
}

// namedBack gives the model's calls in a chat answer (one JSON body, or an
// SSE stream's chunks) the names the client gave its tools.
function namedBack(v, names) {
  let changed = false
  for (const c of Array.isArray(v?.choices) ? v.choices : []) {
    for (const at of [c?.message, c?.delta]) {
      for (const tc of Array.isArray(at?.tool_calls) ? at.tool_calls : []) {
        const ours = names.get(tc?.function?.name)
        if (ours) {
          tc.function.name = ours
          changed = true
        }
      }
    }
  }
  return changed
}

// renamed is res with namedBack on its body, read as it comes.
function renamed(res, names) {
  if (!names.size || !res.body) return res
  const headers = new Headers(res.headers)
  headers.delete("content-length")
  headers.delete("content-encoding")
  const json = /json/i.test(res.headers.get("content-type") ?? "")
  if (json) {
    const out = res.text().then((text) => {
      try {
        const v = JSON.parse(text)
        return namedBack(v, names) ? JSON.stringify(v) : text
      } catch {
        return text
      }
    })
    return out.then((text) => new Response(text, { status: res.status, statusText: res.statusText, headers }))
  }
  const dec = new TextDecoder()
  const enc = new TextEncoder()
  let rest = ""
  const line = (l) => {
    const m = /^data:\s?(.*)$/.exec(l)
    if (!m || m[1] === "[DONE]") return l
    try {
      const v = JSON.parse(m[1])
      return namedBack(v, names) ? `data: ${JSON.stringify(v)}` : l
    } catch {
      return l
    }
  }
  const body = res.body.pipeThrough(
    new TransformStream({
      transform(chunk, ctl) {
        rest += dec.decode(chunk, { stream: true })
        const lines = rest.split("\n")
        rest = lines.pop()
        if (lines.length) ctl.enqueue(enc.encode(lines.map(line).join("\n") + "\n"))
      },
      flush(ctl) {
        rest += dec.decode()
        if (rest) ctl.enqueue(enc.encode(line(rest)))
      },
    }),
  )
  return new Response(body, { status: res.status, statusText: res.statusText, headers })
}

// ---- signing in -------------------------------------------------------------

// poll asks path until WorkBuddy answers with data, retrying the codes
// that mean "not yet".
async function poll(site, path, headers, retry, deadline) {
  for (;;) {
    if (Date.now() > deadline) throw new Error(`${site.name} sign-in timed out`)
    try {
      const data = await call(site, "GET", path, headers)
      if (data && Object.keys(data).length) return data
    } catch (e) {
      if (!(retry.includes(e.code) || e.status === 408 || e.status === 429)) throw e
    }
    await sleep(POLL_MS)
  }
}

async function browserSignIn(site) {
  const state = await call(site, "POST", `/v2/plugin/auth/state?platform=${encodeURIComponent(site.platform)}`, {
    "X-No-Authorization": "true",
    "X-No-User-Id": "true",
    "X-No-Enterprise-Id": "true",
    "X-No-Department-Info": "true",
  }, {})
  if (!state?.state || !state?.authUrl) throw new Error(`${site.name} gave no sign-in page`)
  const url = new URL(state.authUrl)
  if (url.protocol !== "https:") throw new Error(`${site.name}'s sign-in page isn't https`)
  url.searchParams.set("version", APP_VERSION)
  url.searchParams.set("loginSessionId", hex())
  return {
    url: url.toString(),
    instructions: `Sign in to ${site.name} in the browser; this finishes by itself.`,
    method: "auto",
    async callback() {
      try {
        const deadline = Date.now() + SIGN_IN_MS
        const q = encodeURIComponent(state.state)
        const token = await poll(site, `/v2/plugin/auth/token?state=${q}`, {}, [11217], deadline)
        if (!token.accessToken) return { type: "failed", error: `${site.name} sent back no token` }
        let a = merge({}, token)
        const who = await poll(site, `/v2/plugin/login/account?state=${q}`, {
          Authorization: "Bearer " + a.access,
          "X-Domain": domainOf(site, a),
          "X-No-User-Id": "true",
          "X-No-Enterprise-Id": "true",
        }, [12151], deadline)
        a.uid = who.uid ?? ""
        a.enterpriseId = await enterpriseOf(site, a, who)
        return success(site, a, who.nickname || who.phoneNumber || who.uid)
      } catch (e) {
        return { type: "failed", error: e.message }
      }
    },
  }
}

function success(site, a, name) {
  return {
    type: "success",
    refresh: a.refresh ?? "",
    access: a.access,
    expires: a.expires ?? 0,
    accountId: name || site.name,
    uid: a.uid ?? "",
    domain: a.domain ?? "",
    ...(a.enterpriseId ? { enterpriseId: a.enterpriseId } : {}),
    ...(a.refreshExpiresAt ? { refreshExpiresAt: a.refreshExpiresAt } : {}),
    ...(a.tokenType ? { tokenType: a.tokenType } : {}),
  }
}

// desktopFile is where WorkBuddy's desktop app keeps its sign-in.
function desktopFile(site) {
  const home = homedir()
  const base =
    process.platform === "darwin" ? join(home, "Library", "Application Support", "CodeBuddyExtension")
    : process.platform === "win32" ? join(home, "AppData", "Local", "CodeBuddyExtension")
    : join(home, ".local", "share", "CodeBuddyExtension")
  return join(base, "Data", "Public", "auth", site.authID + ".info")
}

// readDesktop is WorkBuddy desktop's sign-in as the app keeps it now, null
// for none (or tokens the app keeps encrypted, which can't be read).
function readDesktop(site) {
  try {
    const f = JSON.parse(readFileSync(desktopFile(site), "utf8"))
    const t = f?.auth ?? {}
    if (typeof t.accessToken !== "string" || !t.accessToken || !f?.account?.uid) return null
    const now = Date.now()
    const acct = f.account
    return {
      access: t.accessToken,
      refresh: typeof t.refreshToken === "string" ? t.refreshToken : "",
      expires: t.expiresAt > 0 ? t.expiresAt : t.expiresIn > 0 ? now + t.expiresIn * 1000 : 0,
      refreshExpiresAt: t.refreshExpiresAt > 0 ? t.refreshExpiresAt : t.refreshExpiresIn > 0 ? now + t.refreshExpiresIn * 1000 : 0,
      domain: typeof t.domain === "string" ? t.domain : "",
      tokenType: typeof t.tokenType === "string" ? t.tokenType : "",
      uid: acct.uid,
      ...(typeof acct.enterpriseId === "string" && acct.enterpriseId.trim() ? { enterpriseId: acct.enterpriseId.trim() } : {}),
      name: acct.nickname || acct.phoneNumber || acct.uid,
    }
  } catch {
    return null
  }
}

// notDesktop says why there is no desktop sign-in to use: WorkBuddy 5.6
// and later seal its tokens at rest ({$wbEncrypted: 1, envelope}), which
// only the app itself opens (plugins#18), so the browser sign-in is the way;
// else the app isn't signed in.
function notDesktop(site) {
  try {
    const t = JSON.parse(readFileSync(desktopFile(site), "utf8"))?.auth ?? {}
    if (t.accessToken?.$wbEncrypted || t.refreshToken?.$wbEncrypted)
      return `${site.name} desktop keeps its sign-in encrypted (WorkBuddy 5.6 and later), which magpie can't read; sign in with "${site.name} account (browser)" instead`
  } catch {}
  return `${site.name} desktop isn't signed in`
}

// desktopSignIn uses the account WorkBuddy desktop is signed in to: nothing
// is copied (a copied refresh token would be the app's and the plugin's
// both, and the first to use it would sign the other out); its file is
// read each time, as the app keeps it.
function desktopSignIn(site) {
  return {
    url: "",
    instructions: `Uses the account ${site.name} desktop is signed in to.`,
    method: "auto",
    async callback() {
      const d = readDesktop(site)
      if (!d) return { type: "failed", error: notDesktop(site) }
      return { type: "success", refresh: "", access: "", expires: 0, source: "desktop", accountId: d.name || site.name, uid: d.uid }
    },
  }
}

// desktopHeld is what a desktop sign-in was renewed to here, by site and
// account: kept in memory only, never written where the app keeps it.
const desktopHeld = new Map()

// current is the sign-in a stored auth names, fresh: WorkBuddy desktop's,
// read where it keeps it, or one kept here.
async function current(site, client, auth) {
  if (auth?.source !== "desktop") return fresh(site, client, auth)
  const d = readDesktop(site)
  if (!d) throw new Error(notDesktop(site))
  const k = site.id + "|" + d.uid
  const h = desktopHeld.get(k)
  const a = await fresh(site, null, h && h.expires >= d.expires ? h : d)
  desktopHeld.set(k, a)
  return a
}

// ---- allowance ----------------------------------------------------------------

// STATUS_TEXT is Go's http.StatusText, which magpie's built-in said a
// refused meter call with; a status Go has no words for is "HTTP <n>", so
// the card always has an error.
const STATUS_TEXT = {
  100: "Continue", 101: "Switching Protocols", 102: "Processing", 103: "Early Hints",
  200: "OK", 201: "Created", 202: "Accepted", 203: "Non-Authoritative Information", 204: "No Content", 205: "Reset Content",
  206: "Partial Content", 207: "Multi-Status", 208: "Already Reported", 226: "IM Used",
  300: "Multiple Choices", 301: "Moved Permanently", 302: "Found", 303: "See Other", 304: "Not Modified", 305: "Use Proxy",
  307: "Temporary Redirect", 308: "Permanent Redirect",
  400: "Bad Request", 401: "Unauthorized", 402: "Payment Required", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed",
  406: "Not Acceptable", 407: "Proxy Authentication Required", 408: "Request Timeout", 409: "Conflict", 410: "Gone",
  411: "Length Required", 412: "Precondition Failed", 413: "Request Entity Too Large", 414: "Request URI Too Long",
  415: "Unsupported Media Type", 416: "Requested Range Not Satisfiable", 417: "Expectation Failed", 418: "I'm a teapot",
  421: "Misdirected Request", 422: "Unprocessable Entity", 423: "Locked", 424: "Failed Dependency", 425: "Too Early",
  426: "Upgrade Required", 428: "Precondition Required", 429: "Too Many Requests", 431: "Request Header Fields Too Large",
  451: "Unavailable For Legal Reasons",
  500: "Internal Server Error", 501: "Not Implemented", 502: "Bad Gateway", 503: "Service Unavailable", 504: "Gateway Timeout",
  505: "HTTP Version Not Supported", 506: "Variant Also Negotiates", 507: "Insufficient Storage", 508: "Loop Detected",
  510: "Not Extended", 511: "Network Authentication Required",
}
const statusText = (n) => STATUS_TEXT[n] || `HTTP ${n}`

// meter asks the billing API as magpie's built-in did, its errors said
// the same: WorkBuddy's message, else its code, else the HTTP status.
async function meter(site, a, path, body = {}) {
  const res = await fetch(site.endpoint + path, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": "WorkBuddy/" + UA_VERSION,
      Authorization: "Bearer " + a.access, "X-User-Id": a.uid ?? "", "X-Domain": domainOf(site, a), "X-Product": "SaaS",
      "X-IDE-Type": "WorkBuddy", ...enterpriseHeaders(a) },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20000),
  })
  let env = {}
  try {
    env = JSON.parse(await res.text()) ?? {}
  } catch {}
  const code = Number.parseInt(env.code, 10) || 0
  if (!res.ok) {
    if (code) throw new Error(env.msg || `error ${code}`)
    if (env.msg) throw new Error(env.msg)
    throw new Error(statusText(res.status))
  }
  if (code) throw new Error(env.msg || `error ${code}`)
  return env.data ?? null
}

// capacity is a capacity the billing API sends, as a string ("438.88")
// or now and then a number; empty is 0.
function capacity(v) {
  if (v == null || v === "") return 0
  if (typeof v === "number") return v
  const s = String(v)
  const n = Number(s)
  if (s.trim() !== s || Number.isNaN(n)) throw new Error(`strconv.ParseFloat: parsing ${JSON.stringify(s)}: invalid syntax`)
  return n
}

// compact is a count as magpie says one: whole, else to two places.
const compact = (n) => (Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, "").replace(/\.$/, ""))

// usageOf is the account's credits, from its resource summary: the plan's
// credits used against what the cycle grants, as magpie's built-in said —
// the count itself too (amount of limit, in credits), for magpie to say it
// as used or left beside the share (magpie#659).
function usageOf(sum, plan) {
  const out = { plan: plan || (sum?.IsPaidUser ? "Pro" : "Free"), windows: [] }
  let total = 0, used = 0
  for (const p of sum?.Packages ?? []) {
    total += capacity(p?.CycleTotalCapacity)
    used += capacity(p?.CycleUsedCapacity)
  }
  if (total > 0) out.windows.push({ name: "Credits", used: (100 * used) / total, display: `${compact(used)} / ${compact(total)}`, amount: used, limit: total, unit: "credits" })
  return out
}

// enterpriseUsageOf is an enterprise (team) account's credits, from
// /billing/meter/get-enterprise-user-usage, the meter WorkBuddy's own usage
// page (www.workbuddy.cn/profile/usage) reads for one (magpie #1904,
// CnsMaple): the resource summary answers such an account with no
// packages at all. It counts the cycle's credits flat — credit used of
// limitNum — and when the cycle began and resets (UTC+8). null when it
// grants none.
function enterpriseUsageOf(u) {
  const limit = capacity(u?.limitNum)
  if (!(limit > 0)) return null
  const used = capacity(u?.credit)
  const w = { name: "Credits", used: (100 * used) / limit, display: `${compact(used)} / ${compact(limit)}`, amount: used, limit, unit: "credits" }
  const at = (v) => (typeof v === "string" && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(v.trim()) ? Date.parse(v.trim().replace(" ", "T") + "+08:00") : 0)
  const reset = at(u?.cycleResetTime), start = at(u?.cycleStartTime)
  if (reset > 0) w.resetsAt = new Date(reset).toISOString()
  if (reset > start && start > 0) w.span = (reset - start) / 1000
  return w
}

// spareFree has the credits windows not count the models that cost none
// (notModels): a model at x0.00 draws no credits, and with the credits
// used up WorkBuddy still serves it (deepseek-v4.1-flash at 560 / 560,
// magpie-community/plugins#138, hheei). Counted, the window at 100% put
// the account last, and behind every other, for its free models too. A
// model free only some hours (a night promotion) is not free here, as in
// the list (priceOf). A list that can't be read leaves the windows as they
// are: every model counted, as before.
async function spareFree(site, a, windows) {
  if (!windows.length) return windows
  let free = []
  try {
    free = (await liveModels(site, a)).filter((m) => m.free).map((m) => m.id)
  } catch {}
  if (free.length) for (const w of windows) w.notModels = free
  return windows
}

// The packages' codes, as WorkBuddy's own client lists them when it asks
// for each package's credits (its COMMODITY_CODES): the API refuses a
// detail list without them (10001 "PackageCodes required").
const CODE = (n, s) => `TCACA_code_${n}_${s}`
const PAID_CODES = [CODE("002", "AkiJS3ZHF5"), CODE("005", "maRGyrHhw1"), CODE("003", "FAnt7lcmRT"), CODE("023", "4xbGhMrE6q"),
  CODE("026", "BaESVICNoi"), CODE("027", "0FCGVA6vSa"), CODE("009", "0XmEQc2xOf"), CODE("038", "OhvqZtiPKr"), CODE("036", "lupO5WgNdG")]
const DAILY_CODE = CODE("001", "PqouKr6QWV")
const FREE_CODES = [DAILY_CODE, CODE("008", "cfWoLwvjU4"), CODE("035", "ArVxJcGDsm"), CODE("006", "DbXS0lrypC"), CODE("039", "KRcQj7wUat"),
  CODE("040", "mi9rCYg46x"), CODE("007", "nzdH5h4Nl0"), CODE("028", "NtpWi0jzXs"), CODE("037", "WxOD3MpI2o"), CODE("029", "6wCGEWquYy"),
  CODE("030", "BjSt89qTvr")]
// a slice package (CapacityType 4) is refreshed each day: its credits are
// lost at the same midnight on every account, so they tell none apart
const SLICE = "4"

// beijing is WorkBuddy's own time ("2026-10-13 00:39:27" is UTC+8, as its
// DeductionEndTime for the same package says).
const beijing = (ms) => new Date(ms + 8 * 3600_000).toISOString().slice(0, 19).replace("T", " ")

// packagesOf is every package of the account with credits, paid and free,
// as WorkBuddy's client asks for them: active and used-up (Status 0, 3),
// up to 10 pages of 200.
async function packagesOf(site, a, now = Date.now()) {
  const day = beijing(now).slice(0, 10)
  const lists = [
    ["/billing/meter/get-user-resource-paid-packages", { PackageCodes: PAID_CODES, NeedRenewInfo: true }],
    ["/billing/meter/get-user-resource-free-packages", { PackageCodes: FREE_CODES, SlicePeriodStartTime: day + " 00:00:00", SlicePeriodEndTime: day + " 23:59:59" }],
  ]
  const out = []
  for (const [path, extra] of lists) {
    for (let page = 1; page <= 10; page++) {
      const d = await meter(site, a, path, { PageNumber: page, PageSize: 200, Status: [0, 3], ...extra })
      const got = d?.Accounts ?? []
      out.push(...got)
      if (got.length < 200 || out.length >= (d?.TotalCount ?? 0)) break
    }
  }
  return out
}

// endOf is when a package's credits are lost: its DeductionEndTime, else
// ExpiredTime, else the cycle's end (UTC+8), as WorkBuddy's client reads it.
function endOf(p) {
  const ms = Number(p?.DeductionEndTime)
  if (ms > 0) return ms
  for (const v of [p?.ExpiredTime, p?.CycleEndTime]) {
    if (typeof v !== "string" || !v.trim()) continue
    const t = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(v.trim()) ? Date.parse(v.trim().replace(" ", "T") + "+08:00") : Date.parse(v)
    if (t > 0) return t
  }
  return 0
}

// runsOutOf is the soonest moment credits left in one of the account's
// packages are lost, and how many (cdredfox on X): smart routing spends
// the account whose credits expire first. Only packages the summary
// counts, with credits left, and not the daily slice; null when none.
function runsOutOf(sum, packages, now = Date.now()) {
  const counted = new Set((sum?.Packages ?? []).map((p) => p?.PackageCode))
  let at = 0, amount = 0
  for (const p of packages ?? []) {
    if (!counted.has(p?.PackageCode) || p?.PackageCode === DAILY_CODE || String(p?.CapacityType) === SLICE) continue
    const left = capacity(p?.CycleCapacityRemainPrecise ?? p?.CycleCapacityRemain)
    const end = endOf(p)
    if (!(left > 0) || end <= now) continue
    if (!at || end < at) at = end, amount = left
    else if (end === at) amount += left
  }
  return at ? { runsOutAt: new Date(at).toISOString(), runsOut: amount } : null
}

// ---- models -----------------------------------------------------------------

// variants are the reasoning levels as OpenCode gives them to the AI SDK.
function variants(efforts) {
  return Object.fromEntries((efforts ?? []).map((e) => [e, { reasoningEffort: e }]))
}

function configModels(site) {
  return Object.fromEntries(site.models.map(([id, name, context, efforts]) => [id, {
    name,
    limit: { context, output: 0 },
    tool_call: true,
    ...(efforts ? { reasoning: true, variants: variants(efforts) } : {}),
  }]))
}

function modelOf(site, provider, m) {
  return {
    id: m.id,
    providerID: provider.id,
    name: m.name,
    api: { id: m.id, url: api(site), npm: NPM },
    status: "active",
    headers: {},
    options: {},
    cost: { input: 0, output: 0, cache: { read: 0, write: 0 } },
    limit: { context: m.context ?? 0, output: m.output ?? 0 },
    capabilities: {
      temperature: true,
      reasoning: !!m.efforts?.length,
      attachment: !!m.images,
      toolcall: true,
      input: { text: true, image: !!m.images, audio: false, video: false, pdf: false },
      output: { text: true, image: false, audio: false, video: false, pdf: false },
      interleaved: false,
    },
    release_date: "",
    variants: variants(m.efforts),
    // magpie's own: served at no cost to the plan's credits
    free: !!m.free,
    // magpie's own: the credits a request costs, as a multiple (0: none)
    rate: m.rate ?? 0,
    // magpie's own: the price before a discount running now (0: none)
    rateWas: m.rateWas ?? 0,
  }
}

// liveModels asks WorkBuddy's product config for the plan's models: the
// "cli" agent's list, each with its details. The CLI User-Agent picks
// WorkBuddy's config (a bare WorkBuddy/<v> gets CodeBuddy IDE's, no cli).
// creditsOf reads a model's credits, the multiple WorkBuddy's picker shows
// by it: "x0.03", "0" or 0; "x0.00" is free. A rate it can't read (or
// none, or an infinite one) is undefined: the model is neither free nor
// rated. The same rule as magpie's built-in (wbCredits).
function creditsOf(c) {
  if (c == null || c === "") return undefined
  const s = String(c).trim().toLowerCase().replace(/^x/, "")
  const n = Number(s)
  return s !== "" && Number.isFinite(n) && n >= 0 ? n : undefined
}

// freeCredits says whether a model's credits are none: "x0.00", "0" or 0.
// A rate it can't read is not free.
function freeCredits(c) {
  return creditsOf(c) === 0
}

// discountOf reads a promotion's price: its discountedCredits ("0.50x",
// "0.00x"), else the factor times the model's own credits.
function discountOf(p, base) {
  const said = creditsOf(String(p.discount?.discountedCredits ?? "").trim().replace(/x$/i, ""))
  if (said !== undefined) return said
  const f = Number(p.discount?.factor)
  return Number.isFinite(f) && f >= 0 && base !== undefined ? base * f : undefined
}

// running says whether a promotion is on at now: enabled, and inside its
// validFrom..validUntil. Its daily hours are not looked at here.
function running(p, now) {
  if (!p || p.enabled === false) return false
  const from = Date.parse(p.schedule?.validFrom ?? "")
  const until = Date.parse(p.schedule?.validUntil ?? "")
  return !(from > now) && !(until <= now)
}

// priceOf is a model's price as magpie keeps it, from its credits and the
// config's modelPromotions (what WorkBuddy's picker shows as 限时免费,
// 夜间免费, 夜间折扣). magpie keeps the list it is given until it asks
// again, so a price that holds only some hours of the day (Hy4 preview,
// free 23:00–8:00 only) is given as its full price, never as free: a list
// asked for at night would otherwise say "free" all day (#121). A discount
// for whole days (Step-5-Preview's 独家限免) is the price now, with the
// price before it as rateWas.
function priceOf(d, promotions, now = Date.now()) {
  const base = creditsOf(d.credits)
  const mine = (Array.isArray(promotions) ? promotions : []).filter(
    (p) => p?.kind === "discount" && Array.isArray(p.modelIds) && p.modelIds.includes(d.id) && running(p, now),
  )
  if (mine.some((p) => Array.isArray(p.schedule?.daily) && p.schedule.daily.length)) {
    // by the hour: the full price, which the credits are unless a night
    // discount already took them to its own price
    const night = mine.filter((p) => p.discount && Array.isArray(p.schedule?.daily) && p.schedule.daily.length)
    if (base === undefined || (base === 0 && night.some((p) => discountOf(p, base) === 0))) return { free: false }
    return { free: false, rate: base }
  }
  const off = mine.filter((p) => p.discount).map((p) => discountOf(p, base)).filter((r) => r !== undefined)
  if (off.length) {
    const r = Math.min(...off)
    return { free: r === 0, rate: r, ...(base !== undefined && base > r ? { rateWas: base } : {}) }
  }
  if (base === undefined) return {}
  return { free: base === 0, rate: base }
}

async function liveModels(site, a) {
  const headers = new Headers()
  sign(site, a, headers)
  headers.set("User-Agent", `CLI/${APP_VERSION} WorkBuddy/${UA_VERSION}`)
  headers.set("X-Requested-With", "XMLHttpRequest")
  headers.set("Accept", "application/json")
  const res = await fetch(site.endpoint + "/v3/config", { headers, signal: AbortSignal.timeout(15000) })
  const env = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(`${site.name}'s config: HTTP ${res.status}`)
  if (env.code) throw new Error(`${site.name}'s config: ${env.msg} (${env.code})`)
  const cfg = env.data ?? {}
  const out = []
  for (const agent of cfg.agents ?? []) {
    if (agent.name !== "cli") continue
    for (const id of agent.models ?? []) {
      const d = (cfg.models ?? []).find((x) => x.id === id)
      const m = { id, name: d?.name || id }
      if (d) {
        m.context = d.maxInputTokens
        m.output = d.maxOutputTokens
        m.images = d.supportsImages === true && !textOnly(site, id)
        Object.assign(m, priceOf(d, cfg.modelPromotions))
        const es = d.reasoning?.supportedEfforts ?? []
        if (es.length) {
          const canOff = d.reasoning?.canDisableThinking
          m.efforts = [...(!d.onlyReasoning && (canOff == null || canOff) ? ["none"] : []), ...es]
        }
      }
      out.push(m)
    }
  }
  // tell apart models the config names alike: deepseek-v4.1-flash and
  // deepseek-v4.1-flash-sg are both "Deepseek-V4.1-Flash"
  const first = new Map()
  for (const m of out) {
    const id = first.get(m.name)
    if (id === undefined) {
      first.set(m.name, m.id)
      continue
    }
    const rest = m.id.startsWith(id + "-") ? m.id.slice(id.length + 1) : ""
    m.name = `${m.name} (${rest ? rest.toUpperCase() : m.id})`
  }
  return out
}

// ---- the plugins --------------------------------------------------------------

// AFTER_TOOLS_REFUSED is WorkBuddy's 400 code 11153, "the conversation must
// end with a user message", which WorkBuddy AI's gemini-3.8-flash answers to a
// chat whose tool results are followed by the user's message (#113): Claude
// Code's reminders, a user's words sent mid-task, a tool's images, which
// magpie hands over in a user message after the results. It does end with a
// user message; the same chat with any other message between them is served.
// The code is matched whole, as with 14018.
const AFTER_TOOLS_REFUSED = /must end with a user message|["']code["']\s*:\s*["']?11153(?![\d.])/i

// replyAfterTools is a chat ending with tool results then the user's
// message(s), with an empty assistant message between them, as if the model
// had said nothing after the results. Tried with a real WorkBuddy AI
// account on 2026-10-14: gemini-3.8-flash serves it and follows the user's
// message as a user's, where folded into the tool's result it was read as
// the tool's output and its ask left undone. null for any other chat — one
// ending with the assistant's message is a prefill, refused as it is.
function replyAfterTools(body) {
  const b = chatOf(body)
  const msgs = b?.messages
  if (!Array.isArray(msgs)) return null
  let i = msgs.length - 1
  while (i >= 0 && msgs[i]?.role === "user") i--
  if (i === msgs.length - 1 || i < 0 || msgs[i]?.role !== "tool") return null
  msgs.splice(i + 1, 0, { role: "assistant", content: "" })
  return JSON.stringify(b)
}

function makePlugin(site) {
  // the models of this site that refused tool results then the user's
  // message, for this run: their next chats go with replyAfterTools at once
  const endsAfterTools = new Set()
  return async ({ client }) => ({
    config: async (config) => {
      config.provider ??= {}
      config.provider[site.id] ??= {}
      const p = config.provider[site.id]
      p.name ??= site.name
      p.npm ??= NPM
      p.api ??= api(site)
      p.models = { ...configModels(site), ...(p.models ?? {}) }
    },
    // the conversation's id, which the chats below carry to WorkBuddy:
    // magpie's (or OpenCode's) session for this request, when it names one
    "chat.headers": async (input, output) => {
      const id = input?.model?.providerID ?? input?.provider?.info?.id
      if (id !== site.id || !input?.sessionID) return
      output.headers[SESSION] = String(input.sessionID).slice(0, 128)
    },
    provider: {
      id: site.id,
      // the account's own list, when it's signed in and WorkBuddy answers;
      // else the list above
      async models(provider, { auth }) {
        if (auth?.type !== "oauth" || !(auth.access || auth.source)) return provider.models
        try {
          const a = await current(site, client, auth)
          const ms = await liveModels(site, a)
          if (!ms.length) return provider.models
          return Object.fromEntries(ms.map((m) => [m.id, modelOf(site, provider, m)]))
        } catch {
          return provider.models
        }
      },
    },
    auth: {
      provider: site.id,
      // magpie renews a browser sign-in LEAD_MS before its end (an hour's
      // token), once for the account, before its requests, models and
      // usage ask; the check before each request stays for OpenCode,
      // which doesn't call this. Desktop's sign-in has no expiry stored
      // and is renewed as before.
      refreshLead: LEAD_MS,
      refresh: (auth) => refreshed(site, auth),
      async loader(getAuth) {
        const auth = await getAuth()
        if (auth?.type !== "oauth") return {}
        return {
          baseURL: api(site),
          apiKey: "",
          async fetch(input, init) {
            let a = await getAuth()
            if (a?.type !== "oauth") throw new Error(`${site.name} isn't signed in`)
            a = await current(site, client, a)
            const req = input instanceof Request ? input : null
            const headers = new Headers(init?.headers ?? req?.headers)
            headers.delete("authorization")
            headers.delete("x-api-key")
            headers.delete("content-length")
            const session = sessionOf(headers)
            sign(site, a, headers)
            let body = init?.body
            if (body === undefined && req) body = await req.clone().text()
            body = withSystem(body)
            const fit = fitted(body)
            body = normalizeToolChoice(fit.body)
            attend(headers, body, session)
            const send = (b) => fetch(req ? req.url : input, { ...init, method: init?.method ?? req?.method, headers, body: b })
            // a model known to turn tool results then the user's message away
            // gets the empty reply between them up front (see endsAfterTools)
            const model = chatOf(body)?.model
            const quiet = endsAfterTools.has(model) ? replyAfterTools(body) : null
            let res = await send(quiet ?? body)
            if (res.status === 400 && !quiet) {
              const text = await res.text()
              const again = AFTER_TOOLS_REFUSED.test(text) ? replyAfterTools(body) : null
              if (again) {
                endsAfterTools.add(model)
                res = await send(again)
              } else {
                res = new Response(text, { status: res.status, statusText: res.statusText, headers: res.headers })
              }
            }
            return res.status >= 400 ? explained(res) : kept(await renamed(res, fit.names))
          },
        }
      },
      // the account's credits, as magpie's built-in showed them; each
      // read keeps the sign-in (signIn), as the built-in's neither marked
      // an account lapsed nor cleared it
      async usage(getAuth) {
        const auth = await getAuth()
        if (auth?.type !== "oauth" || !(auth.access || auth.source)) return { error: "not signed in", signIn: "kept" }
        try {
          const a = await current(site, client, auth)
          // the meter has no /v2 prefix, on either site
          const sum = await meter(site, a, "/billing/meter/get-user-resource-summary")
          const out = usageOf(sum, auth.plan)
          // an enterprise account's summary has no packages: its credits
          // are the enterprise meter's (#1904). A personal account's
          // refusal of it (10001 "uid or enterpriseID is empty") leaves
          // the card as the summary said.
          if (!out.windows.length) {
            let ent = null
            try {
              ent = enterpriseUsageOf(await meter(site, a, "/billing/meter/get-enterprise-user-usage"))
            } catch {}
            if (ent) return { plan: auth.plan || "Enterprise", windows: await spareFree(site, a, [ent]), signIn: "kept" }
          }
          // when the credits left run out, for routing to spend them first;
          // a list that can't be read leaves it unknown, the card stands
          const credits = out.windows.find((w) => w.name === "Credits")
          if (credits) {
            try {
              Object.assign(credits, runsOutOf(sum, await packagesOf(site, a)) ?? {})
            } catch {}
          }
          await spareFree(site, a, out.windows)
          return { ...out, signIn: "kept" }
        } catch (e) {
          return { error: e?.message ?? String(e), signIn: "kept" }
        }
      },
      methods: [
        {
          type: "oauth",
          label: `${site.name} account (browser)`,
          authorize: () => browserSignIn(site),
        },
        {
          type: "oauth",
          label: `${site.name} desktop's sign-in`,
          authorize: async () => desktopSignIn(site),
        },
      ],
    },
  })
}

// REFUSED_HINT is what the user can do about WorkBuddy's "Illegal API
// invocation from an unapproved channel": both builds answer it to a chat
// holding words of Codex's or Claude Code's own (magpie #182), whatever the
// headers. FLAGGED rewrites the ones known; this is for one it doesn't know. It ends the error's message, as magpie's built-in
// put it (provider.WBRefusedHint), so magpie's routing page says it apart.
const REFUSED_HINT =
  "WorkBuddy refuses chats from Codex and Claude Code (their system prompt); use it from Hermes, OpenCode or Pi, or add another provider to this group"
const REFUSED = /unapproved channel|illegal api invocation/i

// RESTRICTED_HINT is what the user can do about WorkBuddy's 403 code 11140
// "request illegal", whose displayMsg says "Your account has been restricted
// due to unusual activity" (magpie #1849): the account is out until WorkBuddy
// lifts the restriction, which an appeal asks for. It ends the error's
// message as magpie's built-in puts it (provider.WBRestrictedHint), word for
// word, so magpie rests the account for hours rather than minutes.
const RESTRICTED_HINT =
  "WorkBuddy restricted this account for unusual activity; it stays out until WorkBuddy lifts that, which an appeal (Submit feedback in WorkBuddy) asks for"
const RESTRICTED_CODE = 11140
// The code is matched whole, as with 14018: 111400 is another error.
const RESTRICTED_TEXT = /account has been restricted due to unusual activity|账号存在异常行为|帳號存在異常行為|["']code["']\s*:\s*["']?11140(?![\d.])/i

// EXHAUSTED_HINT explains WorkBuddy's requirement of an active package
// even for 0-rate / free models. When an account has no packages or 0 credits,
// WorkBuddy returns code 14018 ("Credits exhausted...").
const EXHAUSTED_HINT =
  "WorkBuddy requires an active credit package even for 0-rate free models; check your account package balance"
// The code is matched whole: a code that only begins with 14018 (140185) is
// another error, and insufficient_quota would rest the account as out of credit.
const EXHAUSTED_TEXT = /credits exhausted|额度已用尽|["']code["']\s*:\s*["']?14018(?![\d.])/i

// kept is an answer that went through, saying the sign-in is kept: the
// built-in never cleared a WorkBuddy account's mark, as it never set one.
function kept(res) {
  const headers = new Headers(res.headers)
  headers.set("X-Magpie-Sign-In", "kept")
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers })
}

// explained is res with REFUSED_HINT, RESTRICTED_HINT or EXHAUSTED_HINT added to that refusal's message.
// Each refusal says the sign-in is kept: the built-in passed WorkBuddy's
// 401 on and never marked a WorkBuddy account lapsed.
async function explained(res) {
  const text = await res.text()
  const again = (b) => {
    const headers = new Headers(res.headers)
    headers.delete("content-length")
    headers.delete("content-encoding")
    headers.set("X-Magpie-Sign-In", "kept")
    return new Response(b, { status: res.status, statusText: res.statusText, headers })
  }
  let v
  try {
    v = JSON.parse(text)
  } catch {}
  const at = v?.error && typeof v.error === "object" ? v.error : v && typeof v === "object" ? v : null
  const code = at?.data?.code ?? at?.code ?? v?.code ?? v?.data?.code
  const isRefused = REFUSED.test(text)
  const isRestricted = !isRefused && (Number(code) === RESTRICTED_CODE || RESTRICTED_TEXT.test(text))
  const isExhausted = !isRestricted && (code === 14018 || Number(code) === 14018 || EXHAUSTED_TEXT.test(text))
  if (!isRefused && !isRestricted && !isExhausted) return again(text)

  let msg = text.trim()
  if (at && typeof at.message === "string") msg = at.message
  else if (typeof at?.data?.msg === "string") msg = at.data.msg
  else if (typeof v?.error === "string") msg = v.error
  else if (typeof v?.msg === "string" && v.msg) msg = v.msg // WorkBuddy's own {"code", "msg"}
  else if (typeof v?.data?.msg === "string") msg = v.data.msg

  const hint = isRefused ? REFUSED_HINT : isRestricted ? RESTRICTED_HINT : EXHAUSTED_HINT
  const type = isRefused || isRestricted ? "permission_error" : "insufficient_quota"
  const errCode = isRefused ? null : isRestricted ? RESTRICTED_CODE : 14018
  msg = `${msg} — ${hint}`
  const headers = new Headers(res.headers)
  headers.set("content-type", "application/json")
  headers.delete("content-length")
  headers.delete("content-encoding")
  headers.set("X-Magpie-Sign-In", "kept")
  return new Response(JSON.stringify({ error: { message: msg, type, code: errCode } }), { status: res.status, statusText: res.statusText, headers })
}

export const WorkBuddyAuthPlugin = makePlugin(SITES.workbuddy)
export const WorkBuddyAIAuthPlugin = makePlugin(SITES["workbuddy-ai"])

// for tests
export const _internal = { fitShape, replyAfterTools, AFTER_TOOLS_REFUSED, enterpriseUsageOf, notDesktop, textOnly, runsOutOf, packagesOf, endOf, enterpriseHeaders, enterpriseOf, liveModels, browserSignIn, withSystem, normalizeToolChoice, fitTools, fitted, renamed, unflagged, usageOf, desktopHeld, explained, REFUSED_HINT, RESTRICTED_HINT, EXHAUSTED_HINT, freeCredits, creditsOf, priceOf, fresh, SITES, renewing, renewed, SESSION, attend, turnKey, conversationKey, signatureOf }
